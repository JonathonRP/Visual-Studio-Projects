﻿using System.Web.UI;

namespace MGO.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}