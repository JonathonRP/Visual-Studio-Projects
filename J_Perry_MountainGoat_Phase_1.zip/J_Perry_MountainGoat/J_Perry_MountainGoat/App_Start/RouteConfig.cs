using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Routing;
using Microsoft.AspNet.FriendlyUrls;
using Microsoft.AspNet.FriendlyUrls.Resolvers;

namespace MGO
{
    public static class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            var settings = new FriendlyUrlSettings
            {
                AutoRedirectMode = RedirectMode.Temporary
            };

            routes.EnableFriendlyUrls(settings, new UrlFriendlyResolver());

            //map custom moutain goat outfitters data static routes
            routes.MapPageRoute("", "", "~/Default.aspx");
            routes.MapPageRoute("ProductData", "Data/Product", "~/Data/Employee/ProductData.aspx");
            routes.MapPageRoute("CustomerInfo", "Customer/Info", "~/Data/Employee/CustomerInfo.aspx");
            routes.MapPageRoute("CustomerPurchases", "Customer/Purchases", "~/Data/Employee/CustomerPurchases.aspx");
            routes.MapPageRoute("EmployeeInfo", "Employee/Info", "~/Data/Manager/EmployeeInfo.aspx");
            routes.MapPageRoute("EmployeePurchases", "Employee/Purchases", "~/Data/Manager/EmployeePurchases.aspx");
        }
    }

    public class UrlFriendlyResolver : WebFormsFriendlyUrlResolver
    {
        protected override bool IsMobileExtension(HttpContextBase httpContext, string extension)
        {
            return false;
        }

        public override string ConvertToFriendlyUrl(string path)
        {
            string friendly_url = "";

            if (path.Contains("ProductData.aspx", StringComparison.CurrentCultureIgnoreCase) 
                || path.Contains("CustomerInfo.aspx", StringComparison.CurrentCultureIgnoreCase)
                || path.Contains("CustomerPurchases.aspx", StringComparison.CurrentCultureIgnoreCase)
                || path.Contains("EmployeeInfo.aspx", StringComparison.CurrentCultureIgnoreCase)
                || path.Contains("EmployeePurchases.aspx", StringComparison.CurrentCultureIgnoreCase))
            {
                if (path.Contains("Data/Employee", StringComparison.CurrentCultureIgnoreCase))
                {
                    friendly_url = "~/" + path.Replace("Data/Employee", "", RegexOptions.IgnoreCase).Replace(".aspx", "", RegexOptions.IgnoreCase);
                }
                else
                {
                    friendly_url = "~/" + path.Replace("Data/Manager", "", RegexOptions.IgnoreCase).Replace(".aspx", "", RegexOptions.IgnoreCase);
                }

                string[] url_splits = new string[] { "Product", "Info", "Purchases" };
                string url_split_on = "";

                foreach (var url_split in url_splits)
                {
                    if (path.Contains(url_split, StringComparison.CurrentCultureIgnoreCase))
                    {
                        url_split_on = url_split;
                    }
                }

                if(url_split_on.Equals("Product", StringComparison.CurrentCultureIgnoreCase))
                {
                    return friendly_url.Insert(friendly_url.IndexOf(url_split_on), "/").Replace("Data", "", RegexOptions.IgnoreCase);
                }

                return friendly_url.Insert(friendly_url.IndexOf(url_split_on), "/");
            }
            else if (path.Contains("Report.aspx", StringComparison.CurrentCultureIgnoreCase))
            {
                return "~/" + path.Replace("Report.aspx", "", RegexOptions.IgnoreCase);
            }
            else if (path.Contains("Default.aspx", StringComparison.CurrentCultureIgnoreCase))
            {
                return "~/" + path.Replace("Default.aspx", "", RegexOptions.IgnoreCase);
            }

            return base.ConvertToFriendlyUrl(path);
        }
    }

    public static class Extension
    {
        public static bool Contains(this string text, string value, StringComparison stringComparison)
        {
            return text.IndexOf(value, stringComparison) >= 0;
        }
        public static string Replace (this string input, string search, string replacement, RegexOptions regexOptions)
        {
            return Regex.Replace(input, Regex.Escape(search), replacement.Replace("$", "$$"), regexOptions);
        }
        public static int IndexLength (this string str)
        {
            return str.Length - 1;
        }
    }
}
