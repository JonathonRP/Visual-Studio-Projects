﻿using System.Web.UI;

namespace SportsPro.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}